document.addEventListener('DOMContentLoaded', () => {
    const alertButtons = document.querySelectorAll('[data-alert]');

    alertButtons.forEach((button) => {
        button.addEventListener('click', () => {
            const message = button.dataset.alert || 'Interaksi simulasi';
            alert(message);
        });
    });
});

